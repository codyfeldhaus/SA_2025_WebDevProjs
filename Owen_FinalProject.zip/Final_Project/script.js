//comment here: what do these two lines do?
const circle = document.getElementById('circle');
const scoreDisplay = document.getElementById('score');

//comment here: this line defines the starting value for the score variable
let score = 0;

let randomBallSize;

function clickFunction() {
  clearTimeout(() => {
    setTimeout();
    moveCircle();
  }, 1000);
};

function randomRGB(){
  let r = Math.floor(Math.random()*256);
  let g = Math.floor(Math.random()*256);
  let b = Math.floor(Math.random()*256);
  return `rgb(${r}, ${g}, ${b})`;
}

function randomSize(){
  randomBallSize = Math.floor((Math.random()*75)+25);
  console.log("randomBallSize:", randomBallSize);

  return `${randomBallSize}px`;
}

// Function to move circle to random location
function moveCircle() {
  //comment here: this line of code is making a way to keep track of the variable "game-area"
  const gameArea = document.getElementById('game-area');
  
  //comment here: these lines define the size of the bounding box that the ball pops up in
  const maxX = gameArea.clientWidth - circle.offsetWidth;
  const maxY = gameArea.clientHeight - circle.offsetHeight;

  //comment here: these lines get a random number within the range of applicable numbers and rounds it down to a whole number no matter its decimal value
  const randomX = Math.floor(Math.random() * maxX);
  const randomY = Math.floor(Math.random() * maxY);

  //comment here: these two lines set the position of the circle to the value of the numbers generated
  circle.style.left = `${randomX}px`;
  circle.style.top = `${randomY}px`;

  circle.style.backgroundColor = randomRGB();

  // console.log("randomBallSize:", randomBallSize)

  let newSize = randomSize();
  circle.style.width = newSize;
  circle.style.height = newSize;

}

// Handle circle click
circle.addEventListener('click', () => {
  //comment here: this is active after a click is executed, and adds to the score variable
  score += 1;
  //comment here: this updates the ball's visual location on the screen
  scoreDisplay.textContent = score;
  //comment here: this is the command that runs the previously defined function to 
  moveCircle();
 
  clickFunction();
  
});

// Start the game
moveCircle();
